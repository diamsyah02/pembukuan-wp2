# pembukuan-wp2
 Tugas UAS WP2 Kelompok 1
